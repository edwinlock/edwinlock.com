"""Simulation and symbolic calculations used in the Week 7 teaching material."""
import numpy as np
import sympy as sp

def one_step_wiener(T, rng=None):
    random = np.random.default_rng() if rng is None else rng
    return np.array([0., np.sqrt(T)*random.standard_normal()]), np.array([0., T])

def wiener_interpolate(W, t, repeats=1, rng=None):
    random = np.random.default_rng() if rng is None else rng
    W, t = np.asarray(W, float), np.asarray(t, float)
    for _ in range(repeats):
        new_W = np.empty(2*len(W)-1)
        new_t = np.empty_like(new_W)
        new_W[::2], new_t[::2] = W, t
        new_t[1::2] = (t[:-1]+t[1:])/2
        new_W[1::2] = (W[:-1]+W[1:])/2 + np.sqrt(np.diff(t))/2*random.standard_normal(len(W)-1)
        W, t = new_W, new_t
    return W, t

def simulate_brownian(T, n_steps, cov=None, rng=None):
    cov = np.eye(1) if cov is None else np.asarray(cov)
    random = np.random.default_rng() if rng is None else rng
    L = np.linalg.cholesky(cov)
    dW = np.sqrt(T/n_steps)*(L @ random.standard_normal((len(cov),n_steps)))
    return np.column_stack((np.zeros(len(cov)),np.cumsum(dW,axis=1)))

def simulate_bsm_euler_maruyama(T, S0, mu, sigma, n_steps, rng=None):
    random = np.random.default_rng() if rng is None else rng
    S0, mu, sigma = np.asarray(S0), np.asarray(mu), np.asarray(sigma)
    dt = T/n_steps
    S = np.empty((len(S0),n_steps+1));S[:,0]=S0
    noise = np.sqrt(dt)*(sigma @ random.standard_normal((sigma.shape[1],n_steps)))
    for i in range(n_steps):
        S[:,i+1]=S[:,i]+S[:,i]*(mu*dt+noise[:,i])
    return S

def gbm_terminal_samples(T, S0, mu, sigma, n_steps, n_samples, rng=None):
    random = np.random.default_rng() if rng is None else rng
    S = np.broadcast_to(np.asarray(S0,float),(n_samples,len(S0))).copy()
    dt=T/n_steps
    for _ in range(n_steps):
        eps=random.standard_normal((n_samples,np.shape(sigma)[1]))
        S *= 1+np.asarray(mu)*dt+np.sqrt(dt)*(eps @ np.asarray(sigma).T)
    return S

def euler_maruyama(X0, a, b, W, times):
    """Scalar state and scalar Wiener driver; values include the initial time."""
    W,times=np.asarray(W),np.asarray(times)
    X=np.empty(len(times));X[0]=X0
    for i in range(len(times)-1):
        X[i+1]=X[i]+a(X[i],times[i])*(times[i+1]-times[i])+b(X[i],times[i])*(W[i+1]-W[i])
    return X

def apply_itos_lemma(x, a, b, f, t=None):
    """Independent standard Wiener drivers. Include f_t when t is supplied."""
    x,a,b,f=map(sp.Matrix,(x,a,b,f))
    n,d,k=len(x),b.cols,len(f)
    if a.shape!=(n,1) or b.rows!=n:
        raise ValueError('The coefficient dimensions must match the state.')
    covariance=b*b.T
    drift=sp.zeros(k,1);diffusion=sp.zeros(k,d)
    for I in range(k):
        drift[I]=sp.diff(f[I],t) if t is not None else 0
        for i in range(n):
            drift[I]+=sp.diff(f[I],x[i])*a[i]
            for j in range(n):
                drift[I]+=sp.diff(f[I],x[i],x[j])*covariance[i,j]/2
            for alpha in range(d):
                diffusion[I,alpha]+=sp.diff(f[I],x[i])*b[i,alpha]
    return sp.simplify(drift),sp.simplify(diffusion)
